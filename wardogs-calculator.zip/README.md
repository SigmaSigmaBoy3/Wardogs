# WARDOGS Fire Control Calculator

A standalone HTML calculator for the WARDOGS game.

## Run locally
Double-click `index.html` to open it in a browser.

## Publish
Upload `index.html` to GitHub Pages, Netlify, Cloudflare Pages, or another static web host.

No server, database, npm, or external libraries are required.
